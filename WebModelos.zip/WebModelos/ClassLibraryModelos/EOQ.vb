﻿Public Class EOQ
#Region "variables"
    Private MstrK As Double = -1
    Private Mstrc As Double = -1
    Private Mstrd As Double = -1
    Private Mstrh As Double = -1
    Private MstrL As Double = -1
    Private MstrQ As Double = -1
    Private Mstrt As Double = -1
    Private MstrReorden As Double = -1
    Private MstrCT As Double = -1
    Private MstrTotal As Double = -1
#End Region

#Region "propiedades públicas"
    Public Property K() As Double
        Get
            Return MstrK
        End Get
        Set(ByVal value As Double)
            MstrK = value
        End Set
    End Property

    Public Property c() As Double
        Get
            Return Mstrc
        End Get
        Set(ByVal value As Double)
            Mstrc = value
        End Set
    End Property

    Public Property d() As Double
        Get
            Return Mstrd
        End Get
        Set(ByVal value As Double)
            Mstrd = value
        End Set
    End Property

    Public Property h() As Double
        Get
            Return Mstrh
        End Get
        Set(ByVal value As Double)
            Mstrh = value
        End Set
    End Property

    Public Property Q() As Double
        Get
            Return MstrQ
        End Get
        Set(ByVal value As Double)
            MstrQ = value
        End Set
    End Property

    Public Property L() As Double
        Get
            Return MstrL
        End Get
        Set(ByVal value As Double)
            MstrL = value
        End Set
    End Property

    Public Property t() As Double
        Get
            Return Mstrt
        End Get
        Set(ByVal value As Double)
            Mstrt = value
        End Set
    End Property

    Public Property Reorden() As Double
        Get
            Return MstrReorden
        End Get
        Set(ByVal value As Double)
            MstrReorden = value
        End Set
    End Property

    Public Property CT() As Double
        Get
            Return MstrCT
        End Get
        Set(ByVal value As Double)
            MstrCT = value
        End Set
    End Property

    Public Property Total() As Double
        Get
            Return MstrTotal
        End Get
        Set(ByVal value As Double)
            MstrTotal = value
        End Set
    End Property
#End Region

#Region "métodos"
    Public Sub EOQ()

        For index = 1 To 5
            Try
                If Q = -1 And K = -1 Then
                    Q = t * d
                ElseIf Q = -1 Then
                    Q = Math.Sqrt(2 * d * K / h)
                End If
            Catch ex As Exception
            End Try

            Try
                If t = -1 And Q = -1 Then
                    t = Math.Sqrt(2 * K / (d * h))
                ElseIf t = -1 Then
                    t = Q / d
                End If
            Catch ex As Exception
            End Try

            Try
                If d = -1 And Q = -1 Then
                    d = 2 * K / (Math.Pow(t, 2) * h)
                ElseIf d = -1 And t = -1 And Q = -1 Then
                    d = L / Reorden
                ElseIf d = -1 Then
                    d = Math.Pow(Q, 2) * h / (2 * K)
                End If
            Catch ex As Exception
            End Try
            Try
                If K = -1 And Q = -1 Then
                    Q = t * d
                    K = Math.Pow(Q, 2) * h / (2 * d)
                ElseIf K = -1 Then
                    K = Math.Pow(Q, 2) * h / (2 * d)
                End If
            Catch ex As Exception
            End Try
            Try
                If h = -1 And Q = -1 Then
                    Q = t * d
                    h = 2 * d * K / Math.Pow(Q, 2)
                ElseIf h = -1 Then
                    h = 2 * d * K / Math.Pow(Q, 2)
                End If
            Catch ex As Exception
            End Try
        Next


        For index = 1 To 2
            Try
                If Reorden = -1 Then
                    Reorden = L * d
                    If Reorden > Q Then
                        Dim n As Integer = Int(L / t)
                        Dim Le As Double = L - n * t
                        Reorden = Le * d
                    End If
                End If
            Catch ex As Exception
            End Try

            Try
                If L = -1 Then
                    L = Reorden / d
                End If
            Catch ex As Exception

            End Try
        Next


        For index = 1 To 3
            Try
                If CT = -1 Then
                    CT = K + c * Q + h * Math.Pow(Q, 2) / (2 * d)
                End If
                If Total = -1 Then
                    Total = d * K / Q + d * c + h * Q / 2
                End If
                If c = -1 And Total = -1 Then
                    c = (CT - K - h * Math.Pow(Q, 2) / (2 * d)) / Q
                ElseIf c = -1 Then
                    c = (Total - d * K / Q - h * Q / 2) / d
                End If
            Catch ex As Exception

            End Try

        Next

    End Sub


#End Region
End Class
