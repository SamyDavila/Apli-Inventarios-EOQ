﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub BtnCalcular_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnCalcular.Click
        Dim EOQ As New ClassLibraryModelos.EOQ
        With EOQ
            If Not K.Text = "" Then
                .K = Double.Parse(K.Text)
            End If
            If Not c.Text = "" Then
                .c = Double.Parse(c.Text)
            End If
            If Not d.Text = "" Then
                .d = Double.Parse(d.Text)
            End If
            If Not h.Text = "" Then
                .h = Double.Parse(h.Text)
            End If
            If Not Q.Text = "" Then
                .Q = Double.Parse(Q.Text)
            End If
            If Not t.Text = "" Then
                .t = Double.Parse(t.Text)
            End If
            If Not L.Text = "" Then
                .L = Double.Parse(L.Text)
            End If
            If Not ReOrden.Text = "" Then
                .Reorden = Double.Parse(ReOrden.Text)
            End If
            If Not CT.Text = "" Then
                .CT = Double.Parse(CT.Text)
            End If
            If Not Total.Text = "" Then
                .Total = Double.Parse(Total.Text)
            End If

            .EOQ()
            If K.Text = "" Then
                K.Text = .K
            End If
            If d.Text = "" Then
                d.Text = .d
            End If
            If h.Text = "" Then
                h.Text = .h
            End If
            If Q.Text = "" Then
                Q.Text = Int(.Q)
            End If
            If t.Text = "" Then
                t.Text = .t
            End If
            If L.Text = ""
                L.Text = .L
            End If
            If ReOrden.Text = "" Then
                ReOrden.Text = Int(.Reorden)
            End If
            If c.Text = "" Then
                c.Text = .c
            End If
            If CT.Text = "" Then
                CT.Text = .CT
            End If
            If Total.Text = "" Then
                Total.Text = .Total
            End If
        End With
    End Sub

End Class